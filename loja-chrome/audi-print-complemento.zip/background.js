const CHAVE = 'sessoesAudiPrint';
const ESPERA_DEPOIS_MS = 900;
// Teto para a tela assentar: navegacao lenta adia o print "depois" ate aqui.
const ESPERA_MAX_MS = 8000;
const INTERVALO_PRINT_MS = 550;
const MAX_PASSOS = 40;

// Print de reserva, tirado quando o mouse pousa no elemento. O "antes" pedido
// so depois do clique chega tarde: a pagina ja rodou o handler dela e o Chrome
// ja repintou, entao o "antes" saia mostrando a tela DEPOIS.
const PRE_VALIDA_MS = 5000;
const PRE_INTERVALO_MS = 700;
const pre = new Map();

let ultimoPrint = 0;
let filaPrint = Promise.resolve();
const timers = new Map();
const prazos = new Map();
const locks = new Map();

function comLock(tabId, tarefa) {
  const anterior = locks.get(tabId) || Promise.resolve();
  const atual = anterior.catch(() => {}).then(tarefa);
  const bloqueio = atual.finally(() => {
    if (locks.get(tabId) === bloqueio) locks.delete(tabId);
  });
  locks.set(tabId, bloqueio);
  return atual;
}

/* Retencao da evidencia guardada aqui.
 *
 * A poda por contagem (SESSOES_GUARDADAS) so roda quando uma aba fecha, e so
 * conta: uma gravacao de um cliente sobrevivia indefinidamente enquanto nao
 * aparecessem cinco mais novas depois dela. Prazo em dias resolve o caso que
 * a contagem nao ve, e a checagem mora no todas() de proposito: passa por ela
 * TODO caminho de leitura, entao sessao vencida nao volta por nenhuma porta.
 *
 * Gravacao em andamento nunca vence: o prazo conta do fim, nao do inicio. */
const DIAS_GUARDADOS = 7;
const PRAZO_MS = DIAS_GUARDADOS * 24 * 60 * 60 * 1000;

function vencida(s, agora) {
  if (!s || s.ativa) return false;
  const fim = Date.parse(s.encerrada || s.inicio || '');
  return Number.isFinite(fim) && agora - fim > PRAZO_MS;
}

async function todas() {
  const sessoes = (await chrome.storage.local.get(CHAVE))[CHAVE] || {};
  const agora = Date.now();
  const velhas = Object.keys(sessoes).filter((id) => vencida(sessoes[id], agora));
  if (!velhas.length) return sessoes;
  for (const id of velhas) delete sessoes[id];
  await chrome.storage.local.set({ [CHAVE]: sessoes });
  return sessoes;
}

async function obter(tabId) {
  return (await todas())[tabId] || null;
}

async function gravar(tabId, sessao) {
  const sessoes = await todas();
  if (sessao) sessoes[tabId] = sessao;
  else delete sessoes[tabId];
  await chrome.storage.local.set({ [CHAVE]: sessoes });
}

function capturar(tab) {
  filaPrint = filaPrint.catch(() => {}).then(async () => {
    const espera = Math.max(0, INTERVALO_PRINT_MS - (Date.now() - ultimoPrint));
    if (espera) await new Promise((resolve) => setTimeout(resolve, espera));
    const atual = await chrome.tabs.get(tab.id);
    if (!atual.active) throw new Error('Mantenha a aba do teste visível durante a captura.');
    const imagem = await chrome.tabs.captureVisibleTab(atual.windowId, {
      format: 'jpeg',
      quality: 78
    });
    ultimoPrint = Date.now();
    return imagem;
  });
  return filaPrint;
}

/* Guarda um print recente da aba, para servir de "antes" no proximo passo. */
function preCapturar(tabId) {
  const anterior = pre.get(tabId);
  if (anterior && Date.now() - anterior.quando < PRE_INTERVALO_MS) return anterior.pronta;
  const quando = Date.now();
  const pronta = (async () => {
    const tab = await chrome.tabs.get(tabId);
    if (!tab.active) throw new Error('aba escondida');
    return { imagem: await capturar(tab), url: tab.url || '' };
  })();
  pronta.catch(() => {});   // aba escondida ou limite do Chrome: segue sem reserva
  pre.set(tabId, { quando, pronta });
  return pronta;
}

/* O "antes" bom e o print de reserva, tirado ANTES do clique. So vale se for
 * recente e da mesma pagina; fora disso captura na hora, como antes. */
async function antesDe(tab) {
  const p = pre.get(tab.id);
  pre.delete(tab.id);
  // Espera a reserva em andamento em vez de tirar outro print: disparar um
  // segundo agora so entraria na fila atras dela, saindo ainda mais tarde.
  if (p && Date.now() - p.quando <= PRE_VALIDA_MS) {
    try {
      const { imagem, url } = await p.pronta;
      if (url === (tab.url || '')) return imagem;
    } catch (_) { /* reserva falhou: cai para a captura na hora */ }
  }
  return capturar(tab);
}

function limparTimer(tabId) {
  const timer = timers.get(tabId);
  if (timer) clearTimeout(timer);
  timers.delete(tabId);
}

/* O titulo e a frase que o QA le na evidencia; o campo `acao` fica com o verbo
 * cru, que e o que o script de automacao usa. */
const FRASES = {
  Clicar: 'Clicou em',
  Preencher: 'Preencheu',
  Limpar: 'Limpou',
  Marcar: 'Marcou',
  Desmarcar: 'Desmarcou',
  'Capturar texto': 'Leu'
};

function tituloDo(p) {
  const alvo = p.rotulo || p.seletor;
  const frase = FRASES[p.tipo] || 'Interagiu com';
  if (p.tipo === 'Capturar texto') return `Leu "${p.valor}"`;
  return `${frase} "${alvo}"` + (p.valor ? ` com "${p.valor}"` : '');
}

async function finalizar(tabId) {
  limparTimer(tabId);
  prazos.delete(tabId);
  return comLock(tabId, async () => {
    const sessao = await obter(tabId);
    if (!sessao?.ativa || !sessao.pendente || sessao.finalizando) return;
    sessao.finalizando = true;
    await gravar(tabId, sessao);

    try {
      const tab = await chrome.tabs.get(tabId);
      const comPrints = sessao.capturarPrints !== false;
      const depois = comPrints ? await capturar(tab) : null;
      const textoDepois = await chrome.tabs.sendMessage(tabId, { tipo: 'AUDI_TEXTO' }).catch(() => null);
      const p = sessao.pendente;
      const agora = new Date().toISOString();
      sessao.passos.push({
        id: p.id,
        titulo: tituloDo(p),
        obs: comPrints ? 'Descrição pendente.' : 'Sem print: captura desligada nesta gravação.',
        acao: p.tipo || 'Clicar',
        elemento: p.seletor,
        elementoId: p.elementoId || '',
        rotulo: p.rotulo,
        valor: p.valor || '',
        html: p.html,
        timestampAntes: p.timestampAntes,
        timestampDepois: agora,
        urlAntes: p.urlAntes,
        urlDepois: tab.url || p.urlAntes,
        frameUrl: p.frameUrl || '',
        textoAntes: p.textoAntes || null,
        textoDepois: textoDepois || null,
        imagens: comPrints ? [
          { dataUrl: p.antes, legenda: `Antes · ${new Date(p.timestampAntes).toLocaleString('pt-BR')}` },
          { dataUrl: depois, legenda: `Depois · ${new Date(agora).toLocaleString('pt-BR')}` }
        ] : []
      });
      if (sessao.passos.length > MAX_PASSOS) sessao.passos.shift();
      /* A proxima da fila vira o pendente. O "antes" dela e este "depois": os
       * dois sao o instante em que ela chegou, e um print novo agora ja sairia
       * com o efeito dela na tela. */
      const proxima = (sessao.fila || []).shift();
      sessao.pendente = proxima ? { ...proxima, antes: depois } : null;
      sessao.finalizando = false;
      await gravar(tabId, sessao);
      if (proxima) agendarFinalizacao(tabId);
      /* AWAIT de proposito, nao "atire e esqueca": no service worker do
       * Manifest V3, uma chamada assincrona disparada sem await nao segura
       * o worker vivo, e o Chrome pode encerra-lo assim que finalizar()
       * devolve o controle -- abandonando o push a meio caminho, calado, sem
       * erro nenhum. Foi exatamente esse o bug que fazia o passo fechar e
       * salvar (isso e' sincrono) mas nao empurrar: o service worker morria
       * antes do chrome.tabs.sendMessage() la dentro rodar. */
      await empurrarParaPrint(sessao.passos[sessao.passos.length - 1], sessao);
    } catch (erro) {
      sessao.finalizando = false;
      sessao.erro = erro.message;
      await gravar(tabId, sessao);
    }
  });
}

/* Parar logo depois de preencher e clicar: fecha tambem o que esta na fila. */
async function finalizarTudo(tabId) {
  for (let i = 0; i <= MAX_PASSOS; i++) {
    await finalizar(tabId);
    const s = await obter(tabId);
    if (!s?.pendente || s.erro) return;
  }
}

/* Cada evento adia o print "depois" em ESPERA_DEPOIS_MS, para pegar a tela ja
 * assentada. O prazo impede que uma pagina que nunca para de mexer (ticker,
 * banner rotativo) adie o passo para sempre. */
function agendarFinalizacao(tabId) {
  limparTimer(tabId);
  if (!prazos.has(tabId)) prazos.set(tabId, Date.now() + ESPERA_MAX_MS);
  const restante = prazos.get(tabId) - Date.now();
  const espera = Math.max(0, Math.min(ESPERA_DEPOIS_MS, restante));
  timers.set(tabId, setTimeout(() => finalizar(tabId), espera));
}

/* O content script nao sabe sozinho se a sessao esta gravando, e o realce so
 * pode existir durante a gravacao. Avisar falha de proposito calado em aba sem
 * content script (chrome://, PDF, aba recem-aberta). */
/* Onde o Print pode estar aberto. Mesma lista do content script: se mudar aqui,
 * mude la tambem.
 *
 * Dois dominios Railway de proposito: o do usuario (audiprint) e o espelho
 * temporario (audi-print-production), que e o que esta no ar hoje. Sem o
 * segundo aqui, a extensao gravava certinho mas nunca achava a aba do Print
 * para empurrar o passo -- a gravacao "sumia" sem erro nenhum na tela. */
const ABAS_PRINT = ['https://audiprint.up.railway.app/*',
  'https://auditeste-print-production.up.railway.app/*',
  // Endereco antigo, ate todo mundo trocar de favorito (migrado em 12/11/2026).
  'https://audi-print-production.up.railway.app/*',
  'http://localhost/*', 'http://127.0.0.1/*'];

/* Passo pronto vai direto para o Print, sem o usuario ir la clicar em trazer.
 * Falha calada de proposito: sem o Print aberto nao ha para quem mandar, e a
 * gravacao continua guardada para o botao manual. */
async function empurrarParaPrint(passo, sessao) {
  let abas = [];
  try { abas = await chrome.tabs.query({ url: ABAS_PRINT }); } catch (_) { return; }
  for (const aba of abas) {
    await chrome.tabs.sendMessage(aba.id, {
      tipo: 'AUDI_NOVO_PASSO',
      passo,
      origem: { url: sessao.url || '', titulo: sessao.titulo || '' }
    }).catch(() => {});
  }
}

/* O Print manda armar quando voce inicia a gravacao. A sessao nao pode comecar
 * na aba do Print, entao ela comeca na primeira aba de site que voce abrir ou
 * focar depois disso — que e exatamente a aba que voce vai testar. */
const ARMADO_VALE_MS = 5 * 60 * 1000;

/* O "armado" mora no storage da sessao do navegador, nao em variavel.
 *
 * Ate 11/11/2026 era um `let armadoAte` aqui em cima. O Chrome encerra o
 * service worker de Manifest V3 depois de uns 30 s sem evento, e a memoria
 * dele some junto: quem clicava em Iniciar gravacao, preenchia a ficha e so
 * entao ia para o sistema encontrava o complemento desarmado. Nenhuma
 * interacao virava passo, e a evidencia saia so com o print da tela, sem id
 * e sem HTML. Com o painel do service worker aberto (quem desenvolve) ele
 * nunca dorme, e por isso o defeito nao aparecia na maquina de quem testava.
 * storage.session sobrevive ao sono do worker e some ao fechar o navegador,
 * que e exatamente a vida que um "armado" deve ter.
 *
 * Guarda: ate quando vale, se a sessao leva print, e de qual aba e endereco
 * veio o pedido (o Print), para a sessao nunca comecar nele. */
const ARMADO = 'audiPrintArmado';
let armadoNaMemoria = null;   // so para Chrome sem storage.session
async function lerArmado() {
  try { return (await chrome.storage.session.get(ARMADO))[ARMADO] || null; }
  catch (_) { return armadoNaMemoria; }
}
async function gravarArmado(valor) {
  armadoNaMemoria = valor || null;
  try {
    if (valor) await chrome.storage.session.set({ [ARMADO]: valor });
    else await chrome.storage.session.remove(ARMADO);
  } catch (_) { /* fica so na memoria */ }
}

const origemDe = (url) => { try { return new URL(url).origin; } catch (_) { return ''; } };

/* Endereco local so e "o Print" quando e o mesmo de onde a gravacao foi armada.
 *
 * Antes, qualquer http://localhost ou http://127.0.0.1 contava como Print, em
 * qualquer porta. Quem testava um sistema rodando na propria maquina (o caso
 * de todo time que sobe o produto local) clicava em Iniciar gravacao e a
 * sessao nunca comecava na aba do sistema. Os dominios publicados continuam
 * sendo Print sempre. */
function ehAbaDePrint(url, origemQueArmou) {
  const o = origemDe(url);
  if (!o) return false;
  return ORIGENS_PRINT_URL.includes(o) || (!!origemQueArmou && o === origemQueArmou);
}
const ORIGENS_PRINT_URL = ['https://audiprint.up.railway.app',
  'https://auditeste-print-production.up.railway.app',
  'https://audi-print-production.up.railway.app'];

async function comecarSeArmado(tabId) {
  const armado = await lerArmado();
  if (!armado || Date.now() > armado.ate) return;
  let tab;
  try { tab = await chrome.tabs.get(tabId); } catch (_) { return; }
  if (!/^https?:/.test(tab.url || '') || tabId === armado.tabId || ehAbaDePrint(tab.url, armado.origem)) return;
  const jaTem = await obter(tabId);
  if (jaTem?.ativa) return;
  await gravarArmado(null);
  await gravar(tabId, {
    ativa: true,
    inicio: new Date().toISOString(),
    url: tab.url,
    titulo: tab.title || '',
    capturarPrints: armado.comPrints !== false,
    passos: [],
    pendente: null,
    erro: ''
  });
  avisarAba(tabId, true);
}

chrome.tabs.onActivated.addListener(({ tabId }) => { comecarSeArmado(tabId); });

/* Trocar de JANELA nao dispara onActivated. Quem testa com o Print numa janela e
 * o site na outra, lado a lado, nunca via a sessao comecar. */
chrome.windows.onFocusChanged.addListener(async (janelaId) => {
  if (janelaId === chrome.windows.WINDOW_ID_NONE) return;
  const [aba] = await chrome.tabs.query({ active: true, windowId: janelaId }).catch(() => []);
  if (aba) comecarSeArmado(aba.id);
});

/* Abrir uma aba nova ja no site testado tambem conta. */
chrome.tabs.onUpdated.addListener((tabId, info, tab) => {
  if (info.status === 'complete' && tab.active) comecarSeArmado(tabId);
});

function avisarAba(tabId, ativa) {
  chrome.tabs.sendMessage(tabId, { tipo: 'AUDI_SESSAO', ativa }).catch(() => {});
}

/* A outra ponta da conexao que o content script abre a cada acao. So existir
 * ja basta: enquanto a porta esta aberta, o Chrome nao encerra este service
 * worker por inatividade, o que da tempo do setTimeout de
 * agendarFinalizacao() disparar e o push acontecer de verdade. */
chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== 'audi-keepalive') return;
});

/* Instalar ou atualizar alcanca as abas que ja estavam abertas.
 *
 * O Chrome so injeta o content script do manifesto em pagina carregada DEPOIS
 * da instalacao. Quem instalava o complemento e ia direto para a aba do
 * sistema, ja aberta, testava sem ninguem ouvindo: nenhuma interacao virava
 * passo, o Print caia calado para o print da tela e a evidencia saia sem
 * xpath, sem id e sem HTML. Funcionava na maquina de quem ja tinha o
 * complemento e falhava na de quem acabara de instalar. Na atualizacao pela
 * loja acontece o mesmo: a copia antiga fica orfa na aba ate o proximo F5.
 *
 * Aba que recusa (loja do Chrome, PDF, aba descartada) fica de fora sem erro:
 * ela recebe o content script do manifesto quando for recarregada. A copia
 * que por acaso ja estivesse la se aposenta sozinha (ver TROCA no content). */
chrome.runtime.onInstalled.addListener(async () => {
  let abas = [];
  try { abas = await chrome.tabs.query({ url: ['http://*/*', 'https://*/*'] }); } catch (_) { return; }
  await Promise.allSettled(abas.map((aba) => chrome.scripting.executeScript({
    target: { tabId: aba.id, allFrames: true },
    files: ['content.js']
  })));
});

chrome.runtime.onMessage.addListener((msg, sender, responder) => {
  /* O alvo explicito vence o remetente: o popup manda tabId dizendo qual aba
   * gravar, e content script nao manda tabId nenhum. Ao contrario, uma pagina
   * de extensao aberta como aba comum criava a sessao nela mesma. */
  const tabId = msg.tabId ?? sender.tab?.id;
  if (!tabId) return;

  const executar = async () => {
    if (msg.tipo === 'AUDI_STATUS') return { sessao: await obter(tabId) };

    if (msg.tipo === 'AUDI_INICIAR') {
      const armarComPrints = msg.capturarPrints !== false;
      const tab = await chrome.tabs.get(tabId);
      const sessao = {
        ativa: true,
        inicio: new Date().toISOString(),
        url: tab.url,
        titulo: tab.title || '',
        capturarPrints: armarComPrints,
        passos: [],
        pendente: null,
        erro: ''
      };
      await gravar(tabId, sessao);
      avisarAba(tabId, true);
      return { sessao };
    }

    /* Parar de compartilhar a tela encerra a sessao junto: sao a mesma gravacao
     * para quem esta testando. Nao sabemos qual aba, entao para todas as ativas
     * e desarma o que ainda nao comecou. */
    if (msg.tipo === 'AUDI_PARAR_TUDO') {
      await gravarArmado(null);
      const sessoes = await todas();
      for (const [id, s] of Object.entries(sessoes)) {
        if (!s || !s.ativa) continue;
        await finalizarTudo(Number(id));
        const atual = (await todas())[id];
        if (atual) {
          atual.ativa = false;
          await gravar(Number(id), atual);
        }
        avisarAba(Number(id), false);
      }
      return { ok: true };
    }

    /* Excluir o projeto no Print tem que alcancar a copia guardada aqui.
     * Sem isto a evidencia continuava viva na extensao depois de o QA achar
     * que tinha apagado tudo, e voltava na proxima importacao.
     *
     * So o que ja foi trazido para o Print, e nunca uma gravacao em
     * andamento: apagar o que esta sendo gravado agora seria perder trabalho. */
    if (msg.tipo === 'AUDI_DESCARTAR') {
      const sessoes = await todas();
      let apagadas = 0;
      for (const [id, s] of Object.entries(sessoes)) {
        if (!s || s.ativa || !s.importada) continue;
        delete sessoes[id];
        apagadas++;
      }
      if (apagadas) await chrome.storage.local.set({ [CHAVE]: sessoes });
      return { ok: true, apagadas };
    }

    /* Armar: a proxima aba de site que voce focar vira a sessao gravando. */
    if (msg.tipo === 'AUDI_ARMAR') {
      await gravarArmado({
        ate: Date.now() + ARMADO_VALE_MS,
        comPrints: msg.capturarPrints !== false,
        tabId: sender.tab?.id ?? null,
        origem: origemDe(sender.tab?.url)
      });
      // Ja esta numa aba de site? entao comeca nela agora mesmo.
      const [ativa] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
      if (ativa) await comecarSeArmado(ativa.id);
      return { ok: true, armado: true };
    }

    if (msg.tipo === 'AUDI_PARAR') {
      await finalizarTudo(tabId);
      const sessao = await obter(tabId);
      if (sessao) {
        sessao.ativa = false;
        await gravar(tabId, sessao);
      }
      avisarAba(tabId, false);
      return { sessao };
    }

    if (msg.tipo === 'AUDI_LIMPAR') {
      limparTimer(tabId);
      avisarAba(tabId, false);
      await gravar(tabId, null);
      return { sessao: null };
    }

    if (msg.tipo === 'AUDI_ACAO') {
      return comLock(tabId, async () => {
        const sessao = await obter(tabId);
        if (!sessao?.ativa || sessao.finalizando) return { ignorado: true };
        const tab = await chrome.tabs.get(tabId);
        const acao = {
          ...msg.acao,
          timestampAntes: new Date().toISOString(),
          urlAntes: tab.url || msg.acao.urlAntes
        };
        /* Outro passo ainda aberto: esta acao entra na fila, na ordem, em vez
         * de ser descartada. Era assim que digitar a senha e clicar em Entrar
         * perdia um dos dois. O aberto fecha ja (sem await: finalizar espera
         * este lock), para o "depois" dele sair perto do instante desta acao. */
        if (sessao.pendente) {
          (sessao.fila ||= []).push(acao);
          await gravar(tabId, sessao);
          finalizar(tabId);
          return { ok: true, naFila: true };
        }
        const antes = sessao.capturarPrints === false ? null : await antesDe(tab);
        sessao.pendente = { ...acao, antes };
        sessao.erro = '';
        await gravar(tabId, sessao);
        agendarFinalizacao(tabId);
        return { ok: true };
      });
    }

    /* O mouse pousou num elemento clicavel: hora de guardar a reserva. */
    if (msg.tipo === 'AUDI_PRE') {
      const sessao = await obter(tabId);
      if (sessao?.ativa && sessao.capturarPrints !== false && !sessao.pendente && !sessao.finalizando) {
        await preCapturar(tabId);
      }
      return { ok: true };
    }

    if (msg.tipo === 'AUDI_ACAO_CONCLUIDA') {
      agendarFinalizacao(tabId);
      return { ok: true };
    }

    /* Resumo de todas as gravacoes, para o Print listar sem carregar as
     * imagens: uma sessao com 40 passos passa de 20 MB. */
    if (msg.tipo === 'AUDI_EVIDENCIAS') {
      const sessoes = await todas();
      return {
        evidencias: Object.entries(sessoes)
          .filter(([, s]) => s && (s.passos || []).length)
          .map(([id, s]) => ({
            tabId: Number(id),
            url: s.url || '',
            titulo: s.titulo || '',
            inicio: s.inicio || '',
            ativa: !!s.ativa,
            encerrada: s.encerrada || '',
            importada: !!s.importada,
            passos: s.passos.length
          }))
          .sort((a, b) => String(b.inicio).localeCompare(String(a.inicio)))
      };
    }

    /* O Print avisa que ja trouxe esta sessao. Sem isso, abrir um projeto novo
     * herdava a gravacao do teste anterior, de outro sistema. */
    if (msg.tipo === 'AUDI_IMPORTADA') {
      const sessoes = await todas();
      const s = sessoes[msg.deTab];
      if (s) {
        s.importada = true;
        await chrome.storage.local.set({ [CHAVE]: sessoes });
      }
      return { ok: true };
    }

    // A evidencia inteira, no mesmo formato que o botao Exportar gera.
    if (msg.tipo === 'AUDI_EVIDENCIA') {
      const s = (await todas())[msg.deTab];
      if (!s || !(s.passos || []).length) return { erro: 'Nenhuma ação capturada nessa aba.' };
      return {
        evidencia: {
          formato: 'audi-print-evidencia-v1',
          url: s.url || '',
          titulo: s.titulo || '',
          inicio: s.inicio,
          passos: s.passos
        }
      };
    }
  };

  executar().then(responder).catch((erro) => responder({ erro: erro.message }));
  return true;
});

// 'loading' tambem adia: sem isso, uma navegacao que comeca depois dos 900 ms
// pegava o print "depois" na tela velha ou em branco.
chrome.tabs.onUpdated.addListener((tabId, info) => {
  if (info.status !== 'loading' && info.status !== 'complete') return;
  obter(tabId).then((s) => {
    if (s?.ativa && s.pendente) agendarFinalizacao(tabId);
  });
});

/* Fechar a aba testada nao pode jogar a gravacao fora: o fluxo normal e gravar,
 * fechar e abrir o Print para importar. Guarda as ultimas e descarta o resto. */
const SESSOES_GUARDADAS = 5;

chrome.tabs.onRemoved.addListener(async (tabId) => {
  limparTimer(tabId);
  prazos.delete(tabId);
  pre.delete(tabId);
  const sessoes = await todas();
  const s = sessoes[tabId];
  if (!s || !(s.passos || []).length) return gravar(tabId, null);

  s.ativa = false;
  s.encerrada = new Date().toISOString();
  sessoes[tabId] = s;

  const comPassos = Object.entries(sessoes)
    .filter(([, v]) => v && (v.passos || []).length)
    .sort((a, b) => String(b[1].inicio).localeCompare(String(a[1].inicio)));
  for (const [id] of comPassos.slice(SESSOES_GUARDADAS)) delete sessoes[id];

  await chrome.storage.local.set({ [CHAVE]: sessoes });
});
